import pandas as pd
import requests


def ConvertUSD_EGP(amount):
    api_key = "6566e36b009d43b8a25073f2"
    url = f"https://v6.exchangerate-api.com/v6/{api_key}/pair/USD/EGP/{amount}"

    try:
        response = requests.get(url)
        data = response.json()
        if response.status_code == 200:
            converted_amount = data['conversion_result']
            return converted_amount
        else:
            print("Failed To Fetch The Conversion Result. Status Code:", response.status_code)
            return None
    except requests.exceptions.RequestException as e:
        print("Error Fetching Conversion Result:", e)
        return None


USD_EGP_Rate = ConvertUSD_EGP(1)

Employees = pd.read_csv('Employees.csv')

Employees.drop_duplicates(inplace=True)

Employees['Age'] = Employees['Age'].astype(int)

Employees['Salary(USD)'] *= USD_EGP_Rate
ColumnChanges = {
    'Salary(USD)': 'Salary(EGP)'
}
Employees.rename(columns=ColumnChanges, inplace=True)

AverageAge = Employees['Age'].mean()
print("Average Age : ", AverageAge)

MedianSalary = Employees['Salary(EGP)'].median()
print("Median Salary : ", MedianSalary, " EGP")

GenderCount = Employees['Gender'].value_counts()
if 'F' not in GenderCount:
    MaleFemaleRatio = "Its Infinity Because No Female Employee"
else:
    MaleFemaleRatio = GenderCount['M'] / GenderCount['F']

print("Ration between males and female employees is : ", MaleFemaleRatio)

Employees.to_csv('Employees After Modified.csv', index=False)
